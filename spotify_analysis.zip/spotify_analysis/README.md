'''
# Spotify Data Analysis Pipeline

This project provides a modular and reusable Python pipeline for analyzing Spotify music data. It ingests two CSV datasets (tracks and audio features), performs a comprehensive exploratory data analysis (EDA), trains a baseline machine learning model to predict song popularity, and saves all outputs, including plots and reports, automatically.

This pipeline is designed as a portfolio project to demonstrate best practices in data engineering, including modular code, error handling, automated outputs, and a command-line interface (CLI).

## Features

- **Modular Architecture**: The code is organized into logical modules for data loading, analysis, modeling, visualization, and output management.
- **Configurable Inputs**: Specify paths to your track and feature datasets via CLI arguments.
- **Comprehensive EDA**: Performs analyses on:
    - **Popularity**: Identifies top and least popular tracks.
    - **Audio Features**: Explores relationships between features like `danceability`, `energy`, and `loudness` using a correlation matrix and regression plots.
    - **Genre Trends**: Analyzes average popularity and duration across different music genres.
    - **Temporal Trends**: Investigates how the number of songs and their durations have evolved over the years.
- **Baseline ML Model**: Includes an optional module to train a Random Forest or Linear Regression model to predict song popularity.
- **High-Quality Visualizations**: Automatically generates and saves a suite of plots, including heatmaps, regression plots, bar charts, and histograms.
- **Automated Outputs**: Saves all analysis results, including summary tables, analysis reports, and plots, into a structured `outputs` directory.
- **CLI Interface**: A user-friendly command-line interface allows for easy execution and configuration.
- **Error Handling & Validation**: Includes checks for missing files and required data columns.

## Project Structure

```
spotify_analysis_pipeline/
├── data/                     # Placeholder for input CSV files
│   ├── dataset.csv
│   └── SpotifyFeatures.csv
├── outputs/                  # Generated output files
│   ├── plots/                # Saved plots (PNGs)
│   └── reports/              # Saved reports (CSVs)
├── src/                      # Source code modules
│   ├── __init__.py
│   ├── analysis.py           # Core analysis functions
│   ├── data_loader.py        # Data loading and preprocessing
│   ├── modeling.py           # ML modeling functions
│   ├── output_manager.py     # Functions for saving outputs
│   └── visualization.py      # Plotting and visualization
├── tests/                    # (Optional) Unit tests
├── main.py                   # Main executable script
├── requirements.txt          # Python dependencies
└── README.md                 # Project documentation
```

## Getting Started

### Prerequisites

- Python 3.8+
- `pip` for installing packages

### Installation

1.  **Clone the repository (or download the source code):**

    ```bash
    git clone <repository_url>
    cd spotify_analysis_pipeline
    ```

2.  **Install the required dependencies:**

    ```bash
    pip install -r requirements.txt
    ```

3.  **Place your data files:**

    Ensure your Spotify datasets (`dataset.csv` and `SpotifyFeatures.csv`) are placed in the `data/` directory, or specify their paths using the CLI arguments.

### Usage

The main entry point for the pipeline is `main.py`. You can run it from the command line.

**Basic Execution:**

This command runs the full pipeline, including the baseline Random Forest model, using the default dataset paths.

```bash
python main.py
```

**Specifying Custom Data Paths:**

Use the `--tracks` and `--features` arguments to point to your data files.

```bash
python main.py --tracks /path/to/your/tracks.csv --features /path/to/your/features.csv
```

**Skipping the ML Model:**

If you only want to perform the exploratory data analysis, you can skip the model training step.

```bash
python main.py --skip-ml
```

**Choosing a Different ML Model:**

You can choose between `random_forest` (default) and `linear_regression`.

```bash
python main.py --model linear_regression
```

**Specifying a Custom Output Directory:**

All results will be saved to the directory specified by the `--output` argument.

```bash
python main.py --output ./my_analysis_results
```

## Outputs

After a successful run, the `outputs` directory (or your custom specified directory) will be populated with the following:

-   **`outputs/plots/`**: Contains all generated visualizations as PNG images.
    -   `correlation_heatmap.png`
    -   `genre_popularity.png`
    -   `model_predictions.png`
    -   ...and more.
-   **`outputs/reports/`**: Contains all data reports as CSV files.
    -   `summary.csv`: A high-level summary of the datasets.
    -   `top_10_popular_songs.csv`: A list of the most popular tracks.
    -   `genre_statistics.csv`: Aggregated statistics for each genre.
    -   `model_metrics.csv`: Performance metrics (RMSE, R², etc.) for the trained model.
    -   ...and more.
-   **`outputs/analysis_manifest.txt`**: A text file summarizing the completed analysis, including a timestamp and a list of generated output directories.

## Code Modules

-   **`data_loader.py`**: Handles loading CSVs, validating required columns, and initial preprocessing (e.g., converting `duration_ms` to seconds).
-   **`analysis.py`**: Contains the core logic for all exploratory data analysis tasks.
-   **`modeling.py`**: Implements the machine learning workflow, including data preparation, model training (Random Forest, Linear Regression), and evaluation.
-   **`visualization.py`**: Responsible for creating all plots using Matplotlib and Seaborn with a consistent, high-quality style.
-   **`output_manager.py`**: Manages the creation of output directories and the saving of all report files and the final manifest.
-   **`main.py`**: The orchestrator. It parses CLI arguments and calls the other modules in the correct sequence to execute the pipeline.
'''
